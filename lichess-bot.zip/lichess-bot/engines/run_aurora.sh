#!/bin/bash
python3 aurora.py
